package page;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import page.game;
import page.Paging;
public class Buy_Servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String url="jdbc:mysql://localhost:3306/thebase?&serverTimezone=UTC";
    	String user="root";
    	String pass="123456";
    	Connection conn = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	PreparedStatement pst = null;
    	HttpSession session = request.getSession();
    	String acc=(String)session.getAttribute("acc");
		try {
			pst = conn.prepareStatement("select GameName,Type,Price,Address from store,shoppingcar where Customer_id=? and GameName=Store_GameName");
			pst.setString(1, acc);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	ResultSet rs = null;
		try {
			rs = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	List<Object> blist=new ArrayList();
    	try {
			while(rs.next()){
				game game=new game();
				game.gamename=rs.getString(1);
				game.type=rs.getString(2);
				game.price=rs.getFloat(3);
				game.address=rs.getString(4);
				blist.add(game);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	if(blist==null||blist.size()==0) {
    		request.getRequestDispatcher("nothing.jsp").forward(request, response);
    		return;
    	}
        //页面当前页
        int page=0;
        //得到传过来的当前页
        String str_page=    request.getParameter("page");
        Paging bpaging=new Paging();
        bpaging.setList(blist);//从数据库得到数据存入的list集合
        bpaging.setCount();//数据总数
        bpaging.setPagesize(8);//一个页面的数据多少条
        bpaging.setPagenumber();//总的页面数
        bpaging.setEndpage();//最后一页
        bpaging.setIndexpage(1);//第一页
        if (str_page!=null) {
            //将页转换整型判断其大小
            int pag=Integer.parseInt(str_page);
            //当大于零，将传过来的page值赋给当前页page
            if (pag>=0) {
                page=pag;
                //如果小于最大值时则，将其传过来的值减1在赋值给当前页，让其一直在最后一页
                if (pag>(bpaging.getPagenumber()-1)) {
                    page=pag-1;
                }
            }
        }
        bpaging.setPage(page);//最终确认当前页
        List<Object> blist_page =new ArrayList<>();
        //将当前页的值传给新的list_page集合中，list集合是全部数据综合，用i调用其中的几条数据给list_page
        for (int i = bpaging.getPage()*bpaging.getPagesize(); i <(bpaging.getPage()+1)*bpaging.getPagesize()&&i<blist.size(); i++) {
            blist_page.add(blist.get(i));
        }
        //将paging对象其设置在作用域中，以便后面页面调用
        
        session.setAttribute("bpaging", bpaging);
        session.setAttribute("blist", blist_page);
        request.getRequestDispatcher("shop_cart.jsp").forward(request, response);
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
