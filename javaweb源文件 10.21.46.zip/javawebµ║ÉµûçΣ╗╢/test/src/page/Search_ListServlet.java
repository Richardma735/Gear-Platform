package page;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import page.game;
import page.Paging;
public class Search_ListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session = request.getSession();
        //页面当前页
        int page=0;
        //得到传过来的当前页
        String str_page=    request.getParameter("page");
        Paging s_paging=new Paging();
        List l=(List)session.getAttribute("s_list");
        if(l==null||l.size()==0) {
        	request.getRequestDispatcher("nothing.jsp?").forward(request, response);
        	return;
        }
        s_paging.setList(l);//从数据库得到数据存入的list集合
        s_paging.setCount();//数据总数
        s_paging.setPagesize(8);//一个页面的数据多少条
        s_paging.setPagenumber();//总的页面数
        s_paging.setEndpage();//最后一页
        s_paging.setIndexpage(1);//第一页
        if (str_page!=null) {
            //将页转换整型判断其大小
            int pag=Integer.parseInt(str_page);
            //当大于零，将传过来的page值赋给当前页page
            if (pag>=0) {
                page=pag;
                //如果小于最大值时则，将其传过来的值减1在赋值给当前页，让其一直在最后一页
                if (pag>(s_paging.getPagenumber()-1)) {
                    page=pag-1;
                }
            }
        }
        s_paging.setPage(page);//最终确认当前页
        List<Object> s_list_page =new ArrayList<>();
        //将当前页的值传给新的list_page集合中，list集合是全部数据综合，用i调用其中的几条数据给list_page
        for (int i = s_paging.getPage()*s_paging.getPagesize(); i<s_paging.getCount()&&i <(s_paging.getPage()+1)*s_paging.getPagesize(); i++) {
            s_list_page.add(l.get(i));
        }
        //将paging对象其设置在作用域中，以便后面页面调用
        session.setAttribute("s_paging", s_paging);
        session.setAttribute("s_list_page", s_list_page);
        request.getRequestDispatcher("search.jsp").forward(request, response);
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
