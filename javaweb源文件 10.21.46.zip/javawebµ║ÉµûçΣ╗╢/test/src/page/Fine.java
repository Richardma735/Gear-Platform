package page;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import page.game;
import page.Paging;
public class Fine extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String url="jdbc:mysql://localhost:3306/thebase?&serverTimezone=UTC";
    	String user="root";
    	String pass="123456";
    	Connection conn = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	CallableStatement pst = null;
    	HttpSession session=request.getSession();
    	String name=request.getParameter("game");
    	String thegame="中国式家长";
    	if("boxiya".equals(name))thegame="波西亚时光";
    	else if("chineseparent".equals(name))thegame="中国式家长";
    	else thegame=name;
    	String account=(String)session.getAttribute("acc");
		try {
			pst = conn.prepareCall("call good(?,?)");
			pst.setString(1, account);
			pst.setString(2, thegame);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pst.execute();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String[] str=name.split(" ");
        request.getRequestDispatcher(str[0]+".jsp").forward(request, response);
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
