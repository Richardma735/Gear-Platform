package page;
import java.util.Date;
public class game {
    public String gamename;
    public String capacity;
    public String type;
    public float price;
    public String edition;
    public Date  date;
    public String developer;
    public float feedback_rate;
    public String address;
}