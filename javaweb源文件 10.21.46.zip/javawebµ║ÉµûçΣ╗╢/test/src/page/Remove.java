package page;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import page.record;
import page.Paging;
public class Remove extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String url="jdbc:mysql://localhost:3306/thebase?&serverTimezone=UTC";
    	String user="root";
    	String pass="123456";
    	Connection conn = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	PreparedStatement pst = null;
    	HttpSession session = request.getSession();
    	String gamename=request.getParameter("game");
    	String name="中国式家长";
    	if("boxiya".equals(gamename))name="波西亚时光";
    	else if("chineseparent".equals(gamename))name="中国式家长";
    	else name=gamename;
    	String account=(String)session.getAttribute("acc");
		try {
			pst = conn.prepareStatement("delete from shoppingcar where Customer_id=? and Store_GameName=?");
			pst.setString(1, account);
			pst.setString(2, name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        request.getRequestDispatcher("shop_cart.jsp?x="+gamename).forward(request, response);
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
