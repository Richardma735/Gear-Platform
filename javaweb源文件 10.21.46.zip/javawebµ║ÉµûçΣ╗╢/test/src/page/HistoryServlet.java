package page;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import page.record;
import page.Paging;
public class HistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String url="jdbc:mysql://localhost:3306/thebase?&serverTimezone=UTC";
    	String user="root";
    	String pass="123456";
    	Connection conn = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	PreparedStatement pst = null;
    	HttpSession session = request.getSession();
    	String what=request.getParameter("which");
    	String path="surfhistory";
    	String account=(String)session.getAttribute("acc");
        switch(what) {
        case "pur":path="transactionrecord";break;
        case "scan":path="surfhistory";break;
        }
		try {
			pst = conn.prepareStatement("select Store_GameName,Time,Address from store,"+path+" where Customer_id=? and  Store_GameName=GameName");
			pst.setString(1, account);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	ResultSet rs = null;
		try {
			rs = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	List<Object> hlist=new ArrayList();
    	try {
			while(rs!=null&&rs.next()){
				record re=new record();
				re.gamename=rs.getString(1);
				re.date=rs.getDate(2);
				re.adress=rs.getString(3);
				hlist.add(re);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //页面当前页
        int page=0;
        //得到传过来的当前页
        String str_page=    request.getParameter("page");
        Paging hpaging=new Paging();
        if(hlist==null||hlist.size()==0) {
        	request.getRequestDispatcher("nothing.jsp?").forward(request, response);
        	return;
        }
        hpaging.setList(hlist);//从数据库得到数据存入的list集合
        hpaging.setCount();//数据总数
        hpaging.setPagesize(8);//一个页面的数据多少条
        hpaging.setPagenumber();//总的页面数
        hpaging.setEndpage();//最后一页
        hpaging.setIndexpage(1);//第一页
        if (str_page!=null) {
            //将页转换整型判断其大小
            int pag=Integer.parseInt(str_page);
            //当大于零，将传过来的page值赋给当前页page
            if (pag>=0) {
                page=pag;
                //如果小于最大值时则，将其传过来的值减1在赋值给当前页，让其一直在最后一页
                if (pag>(hpaging.getPagenumber()-1)) {
                    page=pag-1;
                }
            }
        }
        hpaging.setPage(page);//最终确认当前页
        List<Object> hlist_page =new ArrayList<>();
        //将当前页的值传给新的list_page集合中，list集合是全部数据综合，用i调用其中的几条数据给list_page
        for (int i = hpaging.getPage()*hpaging.getPagesize(); i <(hpaging.getPage()+1)*hpaging.getPagesize()&&i<hlist.size(); i++) {
            hlist_page.add(hlist.get(i));
        }
        //将paging对象其设置在作用域中，以便后面页面调用
        session.setAttribute("hpaging", hpaging);
        session.setAttribute("hlist", hlist_page);
        request.getRequestDispatcher(what+"_history.jsp").forward(request, response);
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
