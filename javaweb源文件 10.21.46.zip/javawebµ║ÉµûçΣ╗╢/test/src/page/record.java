package page;
import java.util.Date;
public class record {
    public String gamename;
    public Date  date;
    public String adress;
}