package page;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import page.game;
public class TosearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String url="jdbc:mysql://localhost:3306/thebase?&serverTimezone=UTC";
    	String user="root";
    	String pass="123456";
    	Connection conn = null;
    	HttpSession session = request.getSession();
    	String what=request.getParameter("asearch");
		try {
			conn = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement("select * from store where Gamename like '%"+what+"%'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	ResultSet rs = null;
		try {
			rs = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	List<Object> s_list=new ArrayList();
    	try {
			while(rs.next()){
				game game=new game();
				game.gamename=rs.getString(1);
				game.capacity=rs.getString(2);
				game.type=rs.getString(3);
				game.price=rs.getFloat(4);
				game.edition=rs.getString(5);
				game.date=rs.getDate(6);
				game.developer=rs.getString(7);
				game.feedback_rate=rs.getFloat(8);
				game.address=rs.getString(9);
				s_list.add(game);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        session.setAttribute("s_list", s_list);
        request.getRequestDispatcher("Search_ListServlet?page=0").forward(request, response);
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
